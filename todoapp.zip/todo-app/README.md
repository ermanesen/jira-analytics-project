# Görev & Hatırlatıcı (Web Uygulaması / PWA)

Telefon ve bilgisayarda çalışan, mobil uyumlu bir planlama uygulaması.
Tarayıcıdan açılır, "Ana ekrana ekle" ile uygulama gibi kurulabilir ve
internet olmadan da açılır.

## Özellikler

- **3 sekme:** Çok Acil · Acil · Acil Değil (her sekmeye sınırsız madde)
- **Yıldız sistemi:** her madde 1 yıldız 🌟. 30 yıldıza ulaşınca ekranda
  **uçuşan balonlar** ve **"Tebrikler! Çok planlısın"** mesajı.
- **Hatırlatıcılar:**
  - Olay gününden istediğin kadar gün önce (varsayılan 1 gün) bildirim.
  - Bildirim, sen kapatana / gün bitene kadar ekranda **kalıcı** olur
    (`requireInteraction`).
  - Olayı **takvime ekleme** (`.ics` dosyası indirir; telefonda dosyaya
    dokununca takvime eklenir, içinde 1 gün önce alarmı da vardır).
- Veriler cihazda saklanır (localStorage) — hesap/sunucu gerekmez.

## Nasıl çalıştırılır?

Uygulama statik dosyalardan oluşur, derleme gerekmez.

### Yerelde denemek
`todo-app` klasöründe basit bir sunucu başlat:

```bash
cd todo-app
python3 -m http.server 8000
```

Sonra tarayıcıdan `http://localhost:8000` adresini aç.
(Service worker ve bildirimler `http://localhost` veya `https://` üzerinde
çalışır; dosyayı doğrudan `file://` ile açarsan bu özellikler devre dışı kalır.)

### İnternette yayınlamak (telefondan erişmek için)
Telefonda bildirimlerin çalışması için **HTTPS** gerekir. En kolay ücretsiz yol
GitHub Pages:

1. Bu repo > **Settings > Pages**
2. Source: `Deploy from a branch`, branch: `main` (veya bu çalışma dalı), klasör: `/root`
3. Yayınlanan adres + `/todo-app/` ile aç.
   (Alternatif: Netlify / Vercel'e `todo-app` klasörünü sürükle-bırak.)

### Telefona/masaüstüne kurmak
- **Android (Chrome):** menü > "Uygulamayı yükle" / "Ana ekrana ekle"
- **iPhone (Safari):** Paylaş > "Ana Ekrana Ekle"
- **Bilgisayar (Chrome/Edge):** adres çubuğundaki yükle ikonu

## Bildirimler hakkında (önemli)

Web teknolojisinin platform sınırları nedeniyle davranış cihaza göre değişir:

- **Android / masaüstü Chrome & Edge:** *Notification Triggers* API ile bildirim
  uygulama kapalıyken bile planlanan zamanda gösterilir.
- **iPhone (Safari):** Uygulamayı **Ana Ekrana ekledikten** sonra (iOS 16.4+)
  bildirim verilebilir; ancak uygulama tamamen kapalıyken ileri tarihli
  zamanlama iOS tarafından desteklenmez. Bu yüzden uygulama her açıldığında
  zamanı gelmiş hatırlatıcılar kontrol edilip gösterilir ve `.ics` ile takvime
  eklenen olayın kendi alarmı yedek görevi görür.

İlk hatırlatıcıyı eklerken tarayıcı **bildirim izni** isteyecek; "İzin ver" de.

## Dosyalar

| Dosya | Görevi |
|------|--------|
| `index.html` | Arayüz |
| `styles.css` | Mobil uyumlu tasarım |
| `app.js` | Görev/yıldız/hatırlatıcı mantığı, balon animasyonu |
| `sw.js` | Service worker (çevrimdışı + bildirim) |
| `manifest.webmanifest` | PWA tanımı (kurulabilirlik) |
| `icons/icon.svg` | Uygulama ikonu (SVG, her boyutta çalışır) |
| `icons/generate_icons.py` | İstersen PNG ikon üreten script (`pip install pillow`) |
