#!/usr/bin/env python3
"""PNG uygulama ikonlarını üretir (isteğe bağlı).

Uygulama SVG ikonla zaten çalışır. Daha geniş cihaz uyumu (özellikle eski
iPhone/Safari) için PNG istersen:

    pip install pillow
    python3 generate_icons.py

icon-192.png, icon-512.png, icon-180.png dosyalarını bu klasöre yazar.
İstersen manifest.webmanifest ve index.html içinde bu PNG'lere referans
ekleyebilirsin.
"""
import math
from PIL import Image, ImageDraw


def make(size):
    scale = size / 512
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, size, size), radius=int(112 * scale), fill=(79, 70, 229, 255))
    # yıldız
    cx, cy = 256 * scale, 200 * scale
    R = 110 * scale
    r = R * 0.45
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = R if i % 2 == 0 else r
        pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
    d.polygon(pts, fill=(255, 215, 94, 255))
    # liste satırları
    white = (255, 255, 255, 255)
    d.rounded_rectangle((150 * scale, 330 * scale, 180 * scale, 360 * scale), radius=int(7 * scale), fill=white)
    d.rounded_rectangle((200 * scale, 338 * scale, 370 * scale, 352 * scale), radius=int(7 * scale), fill=white)
    d.rounded_rectangle((150 * scale, 385 * scale, 180 * scale, 415 * scale), radius=int(7 * scale), fill=white)
    d.rounded_rectangle((200 * scale, 393 * scale, 370 * scale, 407 * scale), radius=int(7 * scale), fill=white)
    return img


if __name__ == "__main__":
    for s, name in [(192, "icon-192.png"), (512, "icon-512.png"), (180, "icon-180.png")]:
        make(s).save(name)
        print("yazıldı", name)
