/* ============================================================
   Görev & Hatırlatıcı PWA – ana mantık
   ============================================================ */

const STORAGE = {
  tasks: 'tasks_v1',
  reminders: 'reminders_v1',
};

const CATEGORIES = {
  cokAcil: 'Çok Acil',
  acil: 'Acil',
  acilDegil: 'Acil Değil',
};

const MILESTONE = 30;

let state = {
  tasks: load(STORAGE.tasks),
  reminders: load(STORAGE.reminders),
  activeCat: 'cokAcil',
};

/* ---------- Depolama yardımcıları ---------- */
function load(key) {
  try {
    return JSON.parse(localStorage.getItem(key)) || [];
  } catch (_) {
    return [];
  }
}
function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/* ============================================================
   GÖREVLER
   ============================================================ */
const taskList = document.getElementById('task-list');
const starCount = document.getElementById('star-count');

function totalStars() {
  return state.tasks.length;
}

function renderStars() {
  const stars = totalStars();
  starCount.textContent = `${stars % MILESTONE} / ${MILESTONE}`;
}

function renderTasks() {
  const items = state.tasks.filter((t) => t.category === state.activeCat);
  taskList.innerHTML = '';
  if (items.length === 0) {
    taskList.innerHTML =
      '<div class="empty">Henüz madde yok.\nSağ alttaki + ile ekle.</div>';
    renderStars();
    return;
  }
  items.forEach((task) => {
    const row = document.createElement('div');
    row.className = 'item' + (task.done ? ' done' : '');
    row.innerHTML = `
      <span class="star">🌟</span>
      <span class="title"></span>
      <input type="checkbox" ${task.done ? 'checked' : ''} />
      <button class="del" aria-label="Sil">🗑️</button>`;
    row.querySelector('.title').textContent = task.title;
    row.querySelector('input').addEventListener('change', () => toggleTask(task.id));
    row.querySelector('.del').addEventListener('click', () => deleteTask(task.id));
    taskList.appendChild(row);
  });
  renderStars();
}

function addTask(title) {
  title = title.trim();
  if (!title) return;
  state.tasks.push({
    id: uid(),
    title,
    category: state.activeCat,
    done: false,
    createdAt: new Date().toISOString(),
  });
  save(STORAGE.tasks, state.tasks);
  renderTasks();
  // 30'un katına ulaşıldıysa kutla.
  if (totalStars() > 0 && totalStars() % MILESTONE === 0) {
    celebrate();
  }
}

function toggleTask(id) {
  const t = state.tasks.find((x) => x.id === id);
  if (t) t.done = !t.done;
  save(STORAGE.tasks, state.tasks);
  renderTasks();
}

function deleteTask(id) {
  state.tasks = state.tasks.filter((x) => x.id !== id);
  save(STORAGE.tasks, state.tasks);
  renderTasks();
}

/* ============================================================
   HATIRLATICILAR
   ============================================================ */
const reminderList = document.getElementById('reminder-list');

function pad(n) {
  return String(n).padStart(2, '0');
}

/** Bildirimin gönderileceği an (olay günü - kaç gün önce, saatinde). */
function notifyDate(rem) {
  const [h, m] = rem.notifyTime.split(':').map(Number);
  const d = new Date(rem.eventDate + 'T00:00:00');
  d.setDate(d.getDate() - rem.notifyBeforeDays);
  d.setHours(h, m, 0, 0);
  return d;
}

/** Olay gününün sonu (23:59:59). Bildirim bu ana kadar ekranda kalır. */
function endOfEventDay(rem) {
  const d = new Date(rem.eventDate + 'T23:59:59');
  return d;
}

function formatTR(dateObj) {
  return dateObj.toLocaleDateString('tr-TR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

function renderReminders() {
  reminderList.innerHTML = '';
  if (state.reminders.length === 0) {
    reminderList.innerHTML =
      '<div class="empty">Henüz hatırlatıcı yok.\nSağ alttaki + ile ekle.</div>';
    return;
  }
  const sorted = [...state.reminders].sort(
    (a, b) => new Date(a.eventDate) - new Date(b.eventDate)
  );
  sorted.forEach((rem) => {
    const nd = notifyDate(rem);
    const card = document.createElement('div');
    card.className = 'item rem-item';
    card.innerHTML = `
      <div class="rem-top">
        <span class="star">🔔</span>
        <span class="title"></span>
      </div>
      <div class="rem-meta"></div>
      <div class="rem-actions">
        <button class="cal">📅 Takvime ekle</button>
        <button class="del-rem">🗑️ Sil</button>
      </div>`;
    card.querySelector('.title').textContent = rem.title;
    card.querySelector('.rem-meta').textContent =
      `Olay: ${formatTR(new Date(rem.eventDate + 'T00:00:00'))} · ` +
      `Uyarı: ${formatTR(nd)} ${pad(nd.getHours())}:${pad(nd.getMinutes())}`;
    card.querySelector('.cal').addEventListener('click', () => addToCalendar(rem));
    card.querySelector('.del-rem').addEventListener('click', () => deleteReminder(rem.id));
    reminderList.appendChild(card);
  });
}

async function addReminder(data) {
  const rem = {
    id: uid(),
    title: data.title.trim(),
    note: (data.note || '').trim(),
    eventDate: data.eventDate, // 'YYYY-MM-DD'
    notifyBeforeDays: Math.max(0, parseInt(data.notifyBeforeDays || '1', 10)),
    notifyTime: data.notifyTime || '09:00',
    shown: false,
  };
  state.reminders.push(rem);
  save(STORAGE.reminders, state.reminders);
  renderReminders();
  await scheduleNotification(rem);
  // Takvime otomatik eklemek için takvim dosyasını/ bağlantısını aç.
  addToCalendar(rem);
}

function deleteReminder(id) {
  state.reminders = state.reminders.filter((x) => x.id !== id);
  save(STORAGE.reminders, state.reminders);
  renderReminders();
}

/* ---------- Bildirim planlama ---------- */
async function ensureNotifyPermission() {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission !== 'denied') {
    const p = await Notification.requestPermission();
    return p === 'granted';
  }
  return false;
}

async function scheduleNotification(rem) {
  const ok = await ensureNotifyPermission();
  if (!ok) return;

  const when = notifyDate(rem).getTime();
  const reg = await navigator.serviceWorker?.ready.catch(() => null);
  const body = rem.note || `${formatTR(new Date(rem.eventDate + 'T00:00:00'))} için hatırlatıcı`;

  const options = {
    body,
    tag: 'rem-' + rem.id,
    requireInteraction: true, // gün sonuna kadar ekranda kalır (kullanıcı kapatana dek)
    renotify: true,
    icon: 'icons/icon.svg',
    badge: 'icons/icon.svg',
    data: { id: rem.id },
  };

  // 1) Notification Triggers API (Chrome/Edge masaüstü + Android) -> uygulama kapalıyken bile çalışır.
  if (reg && 'showTrigger' in Notification.prototype && 'TimestampTrigger' in window) {
    try {
      await reg.showNotification(rem.title, {
        ...options,
        showTrigger: new TimestampTrigger(when),
      });
      return;
    } catch (e) {
      console.warn('Trigger planlanamadı, yedeğe geçiliyor', e);
    }
  }

  // 2) Yedek: uygulama açıkken setTimeout ile (yakın zamanlıysa).
  scheduleInPageTimer(rem);
}

const pageTimers = {};
function scheduleInPageTimer(rem) {
  clearTimeout(pageTimers[rem.id]);
  const delay = notifyDate(rem).getTime() - Date.now();
  const max = 24 * 60 * 60 * 1000; // 24 saat içindeyse zamanlayıcı kur
  if (delay > 0 && delay <= max) {
    pageTimers[rem.id] = setTimeout(() => fireNotification(rem), delay);
  }
}

async function fireNotification(rem) {
  const ok = await ensureNotifyPermission();
  if (!ok) return;
  const reg = await navigator.serviceWorker?.ready.catch(() => null);
  const body = rem.note || `${formatTR(new Date(rem.eventDate + 'T00:00:00'))} için hatırlatıcı`;
  const options = {
    body,
    tag: 'rem-' + rem.id,
    requireInteraction: true,
    renotify: true,
    icon: 'icons/icon.svg',
    data: { id: rem.id },
  };
  if (reg) reg.showNotification(rem.title, options);
  else new Notification(rem.title, options);

  rem.shown = true;
  save(STORAGE.reminders, state.reminders);
}

/**
 * Uygulama her açıldığında: uyarı zamanı gelmiş ama olay günü henüz bitmemiş
 * hatırlatıcıları kontrol et. (Tarayıcı kapalıyken çalışamadığı durumların yedeği.)
 */
function checkDueReminders() {
  const now = Date.now();
  state.reminders.forEach((rem) => {
    const start = notifyDate(rem).getTime();
    const end = endOfEventDay(rem).getTime();
    if (now >= start && now <= end) {
      if (!rem.shown) fireNotification(rem);
    } else if (now < start) {
      scheduleInPageTimer(rem);
    }
  });
}

/* ---------- Takvime ekleme (.ics + Google Takvim) ---------- */
function icsDate(dateObj) {
  return (
    dateObj.getUTCFullYear() +
    pad(dateObj.getUTCMonth() + 1) +
    pad(dateObj.getUTCDate()) +
    'T' +
    pad(dateObj.getUTCHours()) +
    pad(dateObj.getUTCMinutes()) +
    pad(dateObj.getUTCSeconds()) +
    'Z'
  );
}

function buildICS(rem) {
  const start = new Date(rem.eventDate + 'T09:00:00');
  const end = new Date(rem.eventDate + 'T10:00:00');
  const trigger = `-P${rem.notifyBeforeDays}D`; // olaydan X gün önce alarm
  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//PlanlayiciPWA//TR',
    'CALSCALE:GREGORIAN',
    'BEGIN:VEVENT',
    'UID:' + rem.id + '@planlayici',
    'DTSTAMP:' + icsDate(new Date()),
    'DTSTART:' + icsDate(start),
    'DTEND:' + icsDate(end),
    'SUMMARY:' + escapeICS(rem.title),
    'DESCRIPTION:' + escapeICS(rem.note || ''),
    'BEGIN:VALARM',
    'ACTION:DISPLAY',
    'DESCRIPTION:' + escapeICS(rem.title),
    'TRIGGER:' + trigger,
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');
}

function escapeICS(s) {
  return String(s).replace(/([,;\\])/g, '\\$1').replace(/\n/g, '\\n');
}

function addToCalendar(rem) {
  // Mobil cihazlar .ics dosyasını açınca olayı takvime ekler.
  const blob = new Blob([buildICS(rem)], { type: 'text/calendar' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = rem.title.replace(/[^\w\s-]/g, '') + '.ics';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/* ============================================================
   KUTLAMA (uçuşan balonlar + mesaj)
   ============================================================ */
const celebrationEl = document.getElementById('celebration');
const canvas = document.getElementById('confetti-canvas');
let confettiRAF = null;

function celebrate() {
  celebrationEl.classList.remove('hidden');
  startConfetti();
}

function closeCelebration() {
  celebrationEl.classList.add('hidden');
  if (confettiRAF) cancelAnimationFrame(confettiRAF);
}

function startConfetti() {
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  const colors = ['#e11d48', '#2563eb', '#16a34a', '#f59e0b', '#9333ea', '#db2777', '#0d9488'];
  const balloons = [];
  for (let i = 0; i < 28; i++) {
    balloons.push({
      x: Math.random() * canvas.width,
      y: canvas.height + Math.random() * canvas.height,
      r: 14 + Math.random() * 12,
      speed: 1.2 + Math.random() * 2.2,
      sway: Math.random() * Math.PI * 2,
      color: colors[Math.floor(Math.random() * colors.length)],
    });
  }

  function frame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    balloons.forEach((b) => {
      b.y -= b.speed;
      b.sway += 0.03;
      const x = b.x + Math.sin(b.sway) * 14;
      // balon gövdesi
      ctx.beginPath();
      ctx.ellipse(x, b.y, b.r, b.r * 1.25, 0, 0, Math.PI * 2);
      ctx.fillStyle = b.color;
      ctx.fill();
      // parlama
      ctx.beginPath();
      ctx.ellipse(x - b.r * 0.35, b.y - b.r * 0.4, b.r * 0.2, b.r * 0.35, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      ctx.fill();
      // ip
      ctx.beginPath();
      ctx.moveTo(x, b.y + b.r * 1.25);
      ctx.lineTo(x, b.y + b.r * 1.25 + 22);
      ctx.strokeStyle = 'rgba(255,255,255,0.7)';
      ctx.stroke();
      if (b.y < -60) {
        b.y = canvas.height + 60;
        b.x = Math.random() * canvas.width;
      }
    });
    confettiRAF = requestAnimationFrame(frame);
  }
  frame();
}

/* ============================================================
   ARAYÜZ OLAYLARI
   ============================================================ */
// Tab geçişi
document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
    tab.classList.add('active');
    state.activeCat = tab.dataset.cat;
    renderTasks();
  });
});

// Alt menü görünüm geçişi
const headerTitle = document.getElementById('header-title');
document.querySelectorAll('.nav-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    const view = btn.dataset.view;
    document.getElementById('view-tasks').classList.toggle('active', view === 'tasks');
    document.getElementById('view-reminders').classList.toggle('active', view === 'reminders');
    headerTitle.textContent = view === 'tasks' ? 'Görevlerim' : 'Hatırlatıcılar';
  });
});

// Görev ekle diyaloğu
const taskDialog = document.getElementById('task-dialog');
const taskInput = document.getElementById('task-input');
document.getElementById('add-task-btn').addEventListener('click', () => {
  taskInput.value = '';
  document.getElementById('task-dialog-title').textContent =
    `${CATEGORIES[state.activeCat]} – Yeni madde`;
  taskDialog.showModal();
  setTimeout(() => taskInput.focus(), 50);
});
document.getElementById('task-form').addEventListener('submit', (e) => {
  if (e.submitter && e.submitter.value === 'save') addTask(taskInput.value);
});

// Hatırlatıcı ekle diyaloğu
const reminderDialog = document.getElementById('reminder-dialog');
document.getElementById('add-reminder-btn').addEventListener('click', () => {
  document.getElementById('reminder-form').reset();
  document.getElementById('rem-before').value = '1';
  document.getElementById('rem-time').value = '09:00';
  reminderDialog.showModal();
});
document.getElementById('reminder-form').addEventListener('submit', (e) => {
  if (!(e.submitter && e.submitter.value === 'save')) return;
  addReminder({
    title: document.getElementById('rem-title').value,
    note: document.getElementById('rem-note').value,
    eventDate: document.getElementById('rem-date').value,
    notifyBeforeDays: document.getElementById('rem-before').value,
    notifyTime: document.getElementById('rem-time').value,
  });
});

document.getElementById('celebration-close').addEventListener('click', closeCelebration);

/* ============================================================
   BAŞLAT
   ============================================================ */
function init() {
  renderTasks();
  renderReminders();
  checkDueReminders();
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch((e) => console.warn('SW kaydı başarısız', e));
  }
}
init();
